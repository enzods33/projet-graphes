# Interactions pour le graphe demi_theta6_graph
