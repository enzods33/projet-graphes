# Interactions pour le graphe Yao 4_Linfity

def is_connected(idx1, idx2):
    # TODO: Implémenter la logique de connexion pour Yao 4_Linfity
    return False

def get_graph_type():
    return "Yao 4_Linfity Graph"
